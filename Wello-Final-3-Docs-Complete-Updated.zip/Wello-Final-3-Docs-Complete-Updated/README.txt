Wello — Final 3 Documents

Deploy:
- Upload index.html to the root of your GitHub Pages repository (main branch).
- The file is self-contained and includes the supplied Prompt Medium font.

Updated:
- Homepage headline: สร้างเอกสาร / เสนอลูกค้า / สำหรับธุรกิจของคุณ
- Three equally prominent document cards: Quotation / Invoice / Receipt
- Distinct icons in Wello CI blue, pink and yellow
- English labels enlarged, black, with / prefix
- “สร้างเอกสาร →” converted to prominent blue CTA buttons
- Existing document creation/PDF flow retained
